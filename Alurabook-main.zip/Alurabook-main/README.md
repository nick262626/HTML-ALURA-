# Alurabook
Projeto feito durante o curso de HTML e CSS: responsividade com mobile first da Alura.

## Para visualizar o projeto:
Acesse o link <a href="https://larifar.github.io/Alurabook/">aqui</a>.

## Descrição:
O projeto foi feito usando HTML e CSS. Foi feito um exemplo de um site de leitura de livros.O projeto foi feito com o objetivo de aprendizado da arquitetura baseado no mobile first e responsividade com media queries. 
